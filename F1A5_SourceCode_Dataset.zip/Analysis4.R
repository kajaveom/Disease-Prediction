df = read.csv("symptom_Description.csv",header=T,na.strings=c("",NA))

View(df)
dim(df)
